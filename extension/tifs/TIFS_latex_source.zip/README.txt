LaTeX source for the IEEE T-IFS submission
"Canary-Aware Providers and the Limits of Unlearning Audits:
 A Sharp Bound and the Detectability-Power Trade-off"

main.tex        main manuscript (IEEEtran journal)
supplement.tex  supplementary material
sections/       section files (files starting with "_" belong to the supplement)
tables/         tables and the pgfplots figure
refs.bib        bibliography; main.bbl and supplement.bbl are the compiled versions

Compile each document with: pdflatex, pdflatex (the .bbl files are included;
to regenerate them run bibtex between the two passes).
